const { Router } = require('express');
const router = Router();

const mysqlConnection = require('../database');

router.get('/', (req, res) => {
    console.log("oh no")
    mysqlConnection.query('select * from menu', (error, rows, fields) => {
        console.log("a")
        if(!error) {
            // console.log(rows)
            res.json(rows);
        } else {
            console.log("c")
            console.log(error);
        }
    });
});

router.post('/', (req, res) => {
    console.log("heyyy");
    const { item_name, item_price} = req.body;
    console.log(req.body);
    mysqlConnection.query('insert into menu(item_name, item_price) values (?, ?)', [item_name, item_price], (error, rows, fields) => {
        if(!error) {
            res.json({Status : "Customer saved"})
        } else {
            console.log(error);
        }
    });
})

router.put('/:item_id', (req, res) => {
    const { item_id, item_name, item_price } = req.body;
    console.log(req.body);
    mysqlConnection.query('update menu set item_name = ?, item_price = ? where item_id = ?;', 
        [item_name, item_price,item_id], (error, rows, fields) => {
        if(!error){
            res.json({
                Status: 'menu updated'
            });
        } else {
            console.log(error);
        }
    });
});

router.delete('/:item_id', (req,res) => {
    console.log("its deleting");
    const { item_id } = req.params;
    mysqlConnection.query('delete from menu where item_id = ?', [item_id], (error, rows, fields) => {
        if(!error){
            res.json({
                Status: "menu deleted"
            });
        } else {
            res.json({
                Status: error
            });
        }
    })
});



module.exports = router;
