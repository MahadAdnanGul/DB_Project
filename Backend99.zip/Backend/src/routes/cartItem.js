const { Router } = require('express');
const router = Router();

const mysqlConnection = require('../database');

router.get('/', (req, res) => {
    console.log("oh no")
    mysqlConnection.query('select * from cart', (error, rows, fields) => {
        console.log("a")
        if(!error) {
            // console.log(rows)
            res.json(rows);
        } else {
            console.log("c")
            console.log(error);
        }
    });
});

router.get('/:customer_id', (req, res) => {
    const { customer_id } = req.params;
    mysqlConnection.query('select * from cart where customer_id = ? and status=?', [customer_id,'NP'], (error, rows, fields) => {
        if(!error) {
            res.json(rows);
        } else {
            console.log(error);
        }
    })
});

router.post('/', (req, res) => {
    console.log("cart item post workss");
    const { customer_id, item_name, item_price, item_quantity, hash, status } = req.body;
    // console.log(req.body);
    mysqlConnection.query('insert into cart(customer_id, hash,status,product_name,product_price,product_quantity) values (?, ?,?,?,?,?)', [customer_id, hash, status, item_name, item_price, item_quantity], (error, rows, fields) => {
        if (!error) {
            res.json({ Status: "shopping cart item added" })
        } else {
            console.log(error);
        }
    });
});

router.delete('/:serial_number', (req, res) => {
    const { serial_number } = req.params;
    mysqlConnection.query('delete from cart where serial_number = ?', [serial_number], (error, rows, fields) => {
        if (!error) {
            res.json({
                Status: "User deleted"
            });
        } else {
            res.json({
                Status: error
            });
        }
    })
});

router.put('/:serial_number', (req, res) => {
    const { serial_number, product_quantity } = req.body;
    console.log(req.body);
    mysqlConnection.query('update cart set product_quantity = ? where serial_number = ?;',
        [product_quantity, serial_number], (error, rows, fields) => {
            if (!error) {
                res.json({
                    Status: 'Cart updated'
                    
                });
            } else {
                console.log(error);
            }
        });
});

module.exports = router;
