const { Router } = require('express');
const router = Router();

const mysqlConnection = require('../database');

router.get('/', (req, res) => {
    console.log("oh no")
    mysqlConnection.query('select * from sales', (error, rows, fields) => {
        console.log("a")
        if (!error) {
            console.log(rows)
            res.json(rows);
        } else {
            console.log("c")
            console.log(error);
        }
    });
});
module.exports = router;