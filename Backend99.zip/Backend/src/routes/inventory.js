const { Router } = require('express');
const router = Router();

const mysqlConnection = require('../database');

router.get('/', (req, res) => {
    console.log("oh no")
    mysqlConnection.query('select * from inventory', (error, rows, fields) => {
        console.log("a")
        if (!error) {
            console.log(rows)
            res.json(rows);
        } else {
            console.log("c")
            console.log(error);
        }
    });
});

router.put('/:num', (req, res) => {
    const { num, quantity } = req.body;
    console.log(req.body);
    mysqlConnection.query('update inventory set quantity = ? where num = ?;',
        [quantity,num], (error, rows, fields) => {
            if (!error) {
                res.json({
                    Status: 'inventory updated'
                });
            } else {
                console.log(error);
            }
        });
});

/*router.post('/', (req, res) => {
    console.log("heyyy");
    const { item_name, item_price } = req.body;
    console.log(req.body);
    mysqlConnection.query('insert into menu(item_name, item_price) values (?, ?)', [item_name, item_price], (error, rows, fields) => {
        if (!error) {
            res.json({ Status: "Customer saved" })
        } else {
            console.log(error);
        }
    });
})*/




module.exports = router;