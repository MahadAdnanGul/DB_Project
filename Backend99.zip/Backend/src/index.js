const express = require('express');
const app = express();

const initRoutes = require('./routes/init');
const customerRoutes = require('./routes/customers');
const menuRoutes = require('./routes/menu');
const invetoryRoutes = require('./routes/inventory');
const cartRoutes = require('./routes/cartItem');
const orderRoutes = require('./routes/order');
const salesRoutes = require('./routes/sales');


// Settings
app.set('port', process.env.PORT || 4000);

// Middlewares
app.use(express.json());

// Routes
console.log("at index");
app.use('/', require('./routes/init'));
app.use('/menu', require('./routes/menu'));
app.use('/inventory', require('./routes/inventory'));
app.use('/customers', require('./routes/customers'));
app.use('/cartItem', require('./routes/cartItem'));
app.use('/order', require('./routes/order'));
app.use('/sales', require('./routes/sales'));



// app.use(require('./routes/customer'));

// app.use(require('./routes/dummy'));



// Starting the server
app.listen(app.get('port'), () => {
    console.log('Server on port', app.get('port'));
});