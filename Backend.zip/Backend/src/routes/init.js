const { Router } = require('express');
const router = Router();

const mysqlConnection = require('../database');

router.get('/', (req, res) => {
        // console.log("hi");
        res.status(200).json('Server on port 4000 and Database is connected.');
    });

module.exports = router;
