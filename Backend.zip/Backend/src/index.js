const express = require('express');
const app = express();

const initRoutes = require('./routes/init');
const customerRoutes = require('./routes/customers');
const menuRoutes = require('./routes/menu');
const invetoryRoutes = require('./routes/inventory');
// Settings
app.set('port', process.env.PORT || 4000);

// Middlewares
app.use(express.json());

// Routes
app.use('/', require('./routes/init'));
app.use('/menu', require('./routes/menu'));
app.use('/inventory', require('./routes/inventory'));
app.use('/customers', require('./routes/customers'));



// app.use(require('./routes/customer'));

// app.use(require('./routes/dummy'));



// Starting the server
app.listen(app.get('port'), () => {
    console.log('Server on port', app.get('port'));
});